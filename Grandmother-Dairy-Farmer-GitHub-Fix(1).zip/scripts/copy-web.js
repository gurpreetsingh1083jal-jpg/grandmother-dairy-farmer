const fs = require('node:fs');
const path = require('node:path');

const root = process.cwd();
const webDir = path.join(root, 'www');
fs.mkdirSync(webDir, { recursive: true });

for (const file of ['index.html', 'manifest.webmanifest', 'sw.js', 'style.css']) {
  const source = path.join(root, file);
  if (fs.existsSync(source) && fs.statSync(source).isFile()) {
    fs.copyFileSync(source, path.join(webDir, file));
  }
}

if (!fs.existsSync(path.join(webDir, 'index.html'))) {
  throw new Error('index.html was not copied into www/.');
}
console.log('Web app files copied into www/.');
